<?php
/* ============================================================================
 * b3Ɛq Nigerian Accountancy v2.0.0 — Data Installer
 * tagged: b3Ɛq Nigerian Accountancy
 * File:   htdocs/custom/b3eqng/scripts/install_data.php
 *
 * Called ONCE from modB3eqng::init() on first activation.
 * Executes llx_b3eqng_seed.sql statement by statement, skipping comments
 * and blank lines. Handles multi-row INSERTs correctly.
 * Sets B3EQNG_SEEDED=1 in llx_const on success.
 * ============================================================================
 */

if (!defined('DOL_VERSION')) { die('Forbidden'); }

/**
 * Execute the Nigerian accounting data seed.
 *
 * @param  DoliDB $db       Dolibarr database handler
 * @param  int    $entity   Entity ID
 * @return int              0 on success, -1 on error
 */
function b3eqng_install_data($db, $entity = 1)
{
    $seed_file = DOL_DOCUMENT_ROOT . '/custom/b3eqng/sql/llx_b3eqng_seed.sql';

    if (!file_exists($seed_file)) {
        dol_syslog('b3eqng install_data: seed file not found at ' . $seed_file, LOG_ERR);
        return -1;
    }

    $sql_raw = file_get_contents($seed_file);
    if (!$sql_raw) {
        dol_syslog('b3eqng install_data: could not read seed file', LOG_ERR);
        return -1;
    }

    // If entity != 1, substitute entity references
    if ($entity != 1) {
        $sql_raw = str_replace(
            ['(1,\'NG-IFRS-SME', '(1,\'NG-WHT-', '(1,\'JV-', ', 1,\'chaine', 'entity=1'],
            ['(' . (int)$entity . ',\'NG-IFRS-SME', '(' . (int)$entity . ',\'NG-WHT-',
             '(' . (int)$entity . ',\'JV-', ', ' . (int)$entity . ',\'chaine', 'entity=' . (int)$entity],
            $sql_raw
        );
    }

    $db->begin();
    $errors = 0;

    // Split on semicolons, but only when NOT inside a string.
    // Simple approach: split on ";\n" or ";\r\n" which is safe for this seed file.
    $statements = preg_split('/;\s*\n/', $sql_raw);

    foreach ($statements as $stmt) {
        $stmt = trim($stmt);

        // Skip empty lines, comments-only blocks, SET statements handled separately
        if (empty($stmt)) continue;
        if (preg_match('/^--/m', $stmt) && !preg_match('/^(INSERT|UPDATE|DELETE|CREATE|DROP|ALTER|SELECT)/im', $stmt)) continue;

        // Remove standalone comment lines before executing
        $lines = explode("\n", $stmt);
        $clean_lines = array_filter($lines, function($l) {
            return !preg_match('/^\s*--/', trim($l));
        });
        $clean = trim(implode("\n", $clean_lines));

        if (empty($clean)) continue;

        $res = $db->query($clean);
        if (!$res) {
            $err = $db->lasterrno() . ': ' . $db->lasterror();
            // Ignore duplicate key errors (INSERT IGNORE should handle, but just in case)
            if (strpos($err, '1062') === false && strpos($err, 'Duplicate') === false) {
                dol_syslog('b3eqng install_data SQL error: ' . $err . ' — Statement: ' . substr($clean, 0, 200), LOG_WARNING);
                // Non-fatal: continue seeding, don't rollback on individual insert failure
            }
        }
    }

    if ($errors > 5) {
        $db->rollback();
        dol_syslog('b3eqng install_data: too many errors, rolled back', LOG_ERR);
        return -1;
    }

    $db->commit();
    dol_syslog('b3eqng install_data: seed completed for entity ' . $entity, LOG_INFO);
    return 0;
}
