<?php
/* ============================================================================
 * b3Ɛq Nigerian Accountancy v2.0.0 — Chart of Accounts
 * tagged: b3Ɛq Nigerian Accountancy
 * File:   htdocs/custom/b3eqng/pages/coa.php
 * ============================================================================
 */

require_once dirname(__DIR__) . '/class/b3eqng_init.php';

$b3          = new B3eqNG($db);
$search      = GETPOST('search', 'alphanohtml');
$type_filter = GETPOST('type_filter', 'aZ09');

// FIX: query uses correct column names: numero_compte, label_compte
$sql = "SELECT numero_compte, label_compte, pcg_type, pcg_subtype, active
        FROM llx_accounting_account
        WHERE fk_pcg_version = 'NG-IFRS-SME'
          AND entity = " . (int)$conf->entity;
if ($type_filter && $type_filter !== 'ALL') {
    $sql .= " AND pcg_type = '" . $db->escape($type_filter) . "'";
}
if ($search) {
    $sql .= " AND (numero_compte LIKE '%" . $db->escape($search) . "%'"
          . "  OR label_compte LIKE '%" . $db->escape($search) . "%'"
          . "  OR pcg_subtype LIKE '%" . $db->escape($search) . "%')";
}
$sql .= " ORDER BY numero_compte ASC";

$res      = $db->query($sql);
$accounts = [];
if ($res) { while ($o = $db->fetch_object($res)) { $accounts[] = $o; } }

// All accounts for stats
$sql_all = "SELECT pcg_type, COUNT(*) as cnt FROM llx_accounting_account
            WHERE fk_pcg_version='NG-IFRS-SME' AND entity=" . (int)$conf->entity
          . " GROUP BY pcg_type";
$res_all    = $db->query($sql_all);
$type_count = [];
if ($res_all) { while ($o = $db->fetch_object($res_all)) { $type_count[$o->pcg_type] = (int)$o->cnt; } }
$total = array_sum($type_count);

$type_colors = ['ASSET'=>'#22d3ee','LIABILITIES'=>'#f87171','EQUITY'=>'#a78bfa','INCOME'=>'#34d399','EXPENSE'=>'#fb923c'];

$tax_map = [
    '1101'=>'NG-VAT-INPUT','1102'=>'NG-WHT-CREDIT','2100'=>'NG-VAT-75','2101'=>'NG-VAT-0Z',
    '2110'=>'NG-WHT-DIV','2111'=>'NG-WHT-INT','2112'=>'NG-WHT-RNT','2113'=>'NG-WHT-SUP',
    '2114'=>'NG-WHT-PRF','2115'=>'NG-WHT-DIR','2116'=>'NG-WHT-TEC','2117'=>'NG-WHT-COM',
    '2118'=>'NG-WHT-ROY','2119'=>'NG-WHT-CON','2120'=>'NG-PAYE','2121'=>'NG-PEN-EMP',
    '2122'=>'NG-PEN-EE','2123'=>'NG-NHF','2124'=>'NG-NSITF','2125'=>'NG-ITF',
    '2126'=>'NG-NITDA','2130'=>'NG-CIT','2131'=>'NG-DEVLEVY','2132'=>'NG-CGT','2133'=>'NG-STAMP',
];

llxHeader('', 'Chart of Accounts — b3Ɛq NG Accountancy');
b3eq_inject_css();
?>
<div class="b3eqng-page">
  <div class="b3eqng-header">
    <div class="b3eqng-logo">b3</div>
    <div>
      <div class="b3eqng-header-title">Chart of Accounts</div>
      <div class="b3eqng-header-sub">IFRS for SMEs · <?php echo (int)$total; ?> Accounts · FIRS-aligned · NTA 2025</div>
    </div>
    <div style="margin-left:auto;display:flex;gap:8px;">
      <span class="b3eqng-tag-cyan">NG-IFRS-SME v2</span>
      <span class="b3eqng-tag">NTA 2025</span>
    </div>
  </div>
  <div style="padding:24px 28px;">

    <!-- Stat cards -->
    <div style="display:flex;gap:12px;margin-bottom:20px;flex-wrap:wrap;">
      <?php foreach (['ASSET','LIABILITIES','EQUITY','INCOME','EXPENSE'] as $t): $c = $type_count[$t] ?? 0; $col = $type_colors[$t] ?? '#fff'; ?>
        <div class="b3eqng-stat" style="flex:1;min-width:90px;border-color:<?php echo $col; ?>33;">
          <div class="b3eqng-stat-number" style="color:<?php echo $col; ?>;"><?php echo $c; ?></div>
          <div class="b3eqng-stat-label"><?php echo $t; ?></div>
        </div>
      <?php endforeach; ?>
      <div class="b3eqng-stat" style="flex:1;min-width:90px;">
        <div class="b3eqng-stat-number" style="color:var(--b3eq-gold);"><?php echo (int)$total; ?></div>
        <div class="b3eqng-stat-label">Total</div>
      </div>
    </div>

    <!-- Filters -->
    <form method="GET" style="display:flex;gap:12px;margin-bottom:20px;flex-wrap:wrap;align-items:flex-end;">
      <input name="search" value="<?php echo dol_escape_htmltag($search); ?>"
             placeholder="Search code, name or subtype…" class="b3eqng-input" style="max-width:320px;">
      <select name="type_filter" class="b3eqng-input" style="max-width:180px;">
        <option value="ALL">All Types</option>
        <?php foreach (['ASSET','LIABILITIES','EQUITY','INCOME','EXPENSE'] as $t): ?>
          <option value="<?php echo $t; ?>" <?php echo $type_filter===$t?'selected':''; ?>><?php echo $t; ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="b3eqng-btn">Filter</button>
      <?php if ($search || ($type_filter && $type_filter!=='ALL')): ?>
        <a href="<?php echo dol_buildpath('/custom/b3eqng/pages/coa.php', 1); ?>"
           class="b3eqng-btn" style="background:rgba(255,255,255,0.06);text-decoration:none;">Clear</a>
      <?php endif; ?>
    </form>

    <!-- Table -->
    <div style="overflow-x:auto;">
      <table class="b3eqng-table">
        <thead>
          <tr><th>Code</th><th>Account Name</th><th>Type</th><th>Sub-type</th><th>Dr/Cr</th><th>Tax Code</th></tr>
        </thead>
        <tbody>
          <?php if (empty($accounts)): ?>
            <tr><td colspan="6" style="text-align:center;color:var(--b3eq-muted);padding:32px;">No accounts found. Run the SQL seed via phpMyAdmin.</td></tr>
          <?php else: foreach ($accounts as $i => $a):
            $col   = $type_colors[$a->pcg_type] ?? 'var(--b3eq-text)';
            $normal = in_array($a->pcg_type, ['ASSET','EXPENSE']) ? 'Dr' : 'Cr';
            if (in_array($a->numero_compte, ['1301','1303'])) $normal = 'Cr';
            $tc = $tax_map[$a->numero_compte] ?? '';
          ?>
          <tr style="<?php echo $i%2===0?'':'background:rgba(255,255,255,0.015)'; ?>">
            <td><span class="b3eqng-account-code"><?php echo dol_escape_htmltag($a->numero_compte); ?></span></td>
            <td><?php echo dol_escape_htmltag($a->label_compte); ?></td>
            <td><span style="color:<?php echo $col; ?>;font-weight:700;font-size:11px;"><?php echo dol_escape_htmltag($a->pcg_type); ?></span></td>
            <td><span style="background:rgba(255,255,255,0.05);border:1px solid var(--b3eq-border);border-radius:4px;padding:2px 7px;font-size:10.5px;color:var(--b3eq-muted);"><?php echo dol_escape_htmltag($a->pcg_subtype); ?></span></td>
            <td style="font-weight:700;color:<?php echo $normal==='Dr'?'var(--b3eq-green)':'var(--b3eq-red)'; ?>;"><?php echo $normal; ?></td>
            <td style="font-family:monospace;font-size:11px;color:var(--b3eq-cyan);"><?php echo dol_escape_htmltag($tc); ?></td>
          </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
    <div style="margin-top:8px;color:var(--b3eq-muted);font-size:11px;">
      Showing <?php echo count($accounts); ?> accounts &nbsp;·&nbsp; Entity <?php echo (int)$conf->entity; ?> &nbsp;·&nbsp; v2.0.0
    </div>

    <?php if (empty($accounts)): ?>
    <div class="b3eqng-infobox" style="margin-top:16px;">
      <div class="b3eqng-infobox-title">⚠ No accounts seeded yet</div>
      <p>Run the seed: open <strong>phpMyAdmin</strong> → select your Dolibarr database
         → <strong>Import</strong> → upload <code>sql/llx_b3eqng_seed.sql</code>.<br>
         Or in Dolibarr: Home → Setup → Modules → deactivate b3eqng → reactivate.</p>
    </div>
    <?php endif; ?>

  </div>
</div>
<?php llxFooter(); $db->close(); ?>
