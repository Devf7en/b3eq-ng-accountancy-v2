<?php
/* ============================================================================
 * b3Ɛq Nigerian Accountancy — Core Business Logic
 * tagged: b3Ɛq Nigerian Accountancy
 * File:   htdocs/custom/b3eqng/class/b3eqng.class.php
 *
 * All Nigerian tax calculations, compliance checks, and data retrieval.
 * Used by PHP pages, API endpoints, triggers, and hooks.
 * ============================================================================
 */

if (!defined('DOL_VERSION')) { die('Forbidden'); }

class B3eqNG
{
    /** @var DoliDB */
    public $db;
    public $error  = '';
    public $errors = [];

    // ── Tax constants (NTA 2025) ─────────────────────────────────────────────
    const VAT_STANDARD  = 0.075;
    const VAT_ZERO      = 0.00;

    const CIT_SMALL     = 0.00;
    const CIT_MEDIUM    = 0.20;
    const CIT_LARGE     = 0.30;
    const CIT_SMALL_THRESHOLD  = 100_000_000;
    const CIT_MEDIUM_THRESHOLD = 1_000_000_000;

    const DEV_LEVY      = 0.04;
    const MIN_TAX       = 0.005;  // 0.5% of gross turnover

    const CGT_COMPANY   = 0.30;
    const CGT_INDIVIDUAL= 0.10;

    const PENSION_EMPLOYER = 0.10;
    const PENSION_EMPLOYEE = 0.08;
    const NHF_RATE         = 0.025;
    const NSITF_RATE       = 0.01;
    const ITF_RATE         = 0.01;
    const NITDA_RATE       = 0.01;

    // WHT rates by code
    const WHT_RATES = [
        'NG-WHT-DIV' => 0.10,
        'NG-WHT-INT' => 0.10,
        'NG-WHT-RNT' => 0.10,
        'NG-WHT-ROY' => 0.10,
        'NG-WHT-DIR' => 0.10,
        'NG-WHT-PRF' => 0.10,
        'NG-WHT-TEC' => 0.10,
        'NG-WHT-COM' => 0.10,
        'NG-WHT-SUP' => 0.05,
        'NG-WHT-CON' => 0.025,
    ];

    // PAYE bands [from, to_or_null, rate]
    const PAYE_BANDS = [
        [0,        800_000,    0.07],
        [800_001,  2_400_000,  0.11],
        [2_400_001,4_800_000,  0.15],
        [4_800_001,8_000_000,  0.19],
        [8_000_001,16_000_000, 0.21],
        [16_000_001, null,     0.24],
    ];

    public function __construct(DoliDB $db)
    {
        $this->db = $db;
    }

    // =========================================================================
    // WHT CALCULATION
    // =========================================================================

    /**
     * Calculate Withholding Tax on a gross payment.
     *
     * @param  float  $grossAmount   Gross payment amount in NGN
     * @param  string $whtCode       WHT code e.g. 'NG-WHT-PRF'
     * @param  bool   $hasTIN        Vendor has valid FIRS TIN
     * @param  bool   $smallCoExempt Payer is small co AND amount ≤₦2m/month
     * @return array  { gross, rate, effective_rate, wht_amount, net_payable,
     *                  account_payable, exempt, no_tin_penalty }
     */
    public function calculateWHT(
        float $grossAmount,
        string $whtCode,
        bool $hasTIN = true,
        bool $smallCoExempt = false
    ): array {
        $baseRate = self::WHT_RATES[$whtCode] ?? 0.10;

        // Small company exemption (WHT Regs 2024)
        if ($smallCoExempt && $hasTIN) {
            return [
                'gross'          => $grossAmount,
                'rate'           => $baseRate,
                'effective_rate' => 0.00,
                'wht_amount'     => 0.00,
                'net_payable'    => $grossAmount,
                'account_payable'=> null,
                'exempt'         => true,
                'no_tin_penalty' => false,
                'note'           => 'Exempt: small company + valid TIN + ≤₦2m/month (WHT Regs 2024)',
            ];
        }

        // No-TIN double rate (max 20%)
        $noTinPenalty   = false;
        $effectiveRate  = $baseRate;
        if (!$hasTIN) {
            $effectiveRate = min($baseRate * 2, 0.20);
            $noTinPenalty  = true;
        }

        $whtAmount  = round($grossAmount * $effectiveRate, 2);
        $netPayable = round($grossAmount - $whtAmount, 2);

        // Map code → account
        $codeToAccount = [
            'NG-WHT-DIV' => '2110', 'NG-WHT-INT' => '2111',
            'NG-WHT-RNT' => '2112', 'NG-WHT-SUP' => '2113',
            'NG-WHT-PRF' => '2114', 'NG-WHT-DIR' => '2115',
            'NG-WHT-TEC' => '2116', 'NG-WHT-COM' => '2117',
            'NG-WHT-ROY' => '2118', 'NG-WHT-CON' => '2119',
        ];

        return [
            'gross'          => $grossAmount,
            'rate'           => $baseRate,
            'effective_rate' => $effectiveRate,
            'wht_amount'     => $whtAmount,
            'net_payable'    => $netPayable,
            'account_payable'=> $codeToAccount[$whtCode] ?? '2113',
            'exempt'         => false,
            'no_tin_penalty' => $noTinPenalty,
            'note'           => $noTinPenalty
                ? "No-TIN penalty applied: rate doubled to " . ($effectiveRate * 100) . "%"
                : "Standard WHT at " . ($baseRate * 100) . "%",
        ];
    }

    // =========================================================================
    // VAT CALCULATION
    // =========================================================================

    /**
     * Calculate VAT for a return period.
     *
     * @param  array $salesLines    [['amount' => float, 'type' => 'standard'|'zero'|'exempt'], ...]
     * @param  array $purchaseLines [['amount' => float, 'vat_recoverable' => bool], ...]
     * @return array { output_vat, input_vat, net_vat, payable, refundable,
     *                 total_standard_sales, total_zero_sales, total_exempt_sales,
     *                 total_standard_purchases }
     */
    public function calculateVAT(array $salesLines, array $purchaseLines): array
    {
        $standardSales  = 0;
        $zeroSales      = 0;
        $exemptSales    = 0;
        $outputVAT      = 0;

        foreach ($salesLines as $line) {
            $amt = (float)($line['amount'] ?? 0);
            switch ($line['type'] ?? 'standard') {
                case 'standard':
                    $standardSales += $amt;
                    $outputVAT     += $amt * self::VAT_STANDARD;
                    break;
                case 'zero':
                    $zeroSales += $amt;
                    break;
                case 'exempt':
                    $exemptSales += $amt;
                    break;
            }
        }

        $standardPurchases = 0;
        $inputVAT          = 0;
        foreach ($purchaseLines as $line) {
            $amt = (float)($line['amount'] ?? 0);
            if ($line['vat_recoverable'] ?? true) {
                $standardPurchases += $amt;
                $inputVAT          += $amt * self::VAT_STANDARD;
            }
        }

        $netVAT    = round($outputVAT - $inputVAT, 2);
        $outputVAT = round($outputVAT, 2);
        $inputVAT  = round($inputVAT, 2);

        return [
            'output_vat'              => $outputVAT,
            'input_vat'               => $inputVAT,
            'net_vat'                 => $netVAT,
            'payable'                 => max($netVAT, 0),
            'refundable'              => max(-$netVAT, 0),
            'total_standard_sales'    => $standardSales,
            'total_zero_sales'        => $zeroSales,
            'total_exempt_sales'      => $exemptSales,
            'total_standard_purchases'=> $standardPurchases,
        ];
    }

    // =========================================================================
    // PAYE CALCULATION
    // =========================================================================

    /**
     * Calculate annual PAYE for an employee.
     *
     * @param  float $grossAnnual     Annual gross salary (all emoluments)
     * @param  float $additionalRelief Any additional deductible relief (e.g. NHF)
     * @return array { gross, cra, taxable_income, paye_annual, paye_monthly,
     *                 effective_rate, band_breakdown }
     */
    public function calculatePAYE(float $grossAnnual, float $additionalRelief = 0): array
    {
        // Consolidated Relief Allowance (CRA): higher of ₦200k or 1% of gross, PLUS 20% of gross
        $craBase = max(200_000, $grossAnnual * 0.01);
        $cra     = $craBase + ($grossAnnual * 0.20);
        $cra     = min($cra, $grossAnnual); // Cannot exceed gross

        $taxableIncome = max(0, $grossAnnual - $cra - $additionalRelief);

        $payeAnnual  = 0;
        $breakdown   = [];
        $remaining   = $taxableIncome;

        foreach (self::PAYE_BANDS as [$from, $to, $rate]) {
            if ($remaining <= 0) break;
            $bandSize = $to !== null ? ($to - $from + 1) : PHP_FLOAT_MAX;
            $taxable  = min($remaining, $bandSize);
            $tax      = round($taxable * $rate, 2);
            $breakdown[] = [
                'from' => $from, 'to' => $to,
                'rate' => $rate, 'taxable' => $taxable, 'tax' => $tax,
            ];
            $payeAnnual += $tax;
            $remaining  -= $taxable;
        }

        $payeAnnual  = round($payeAnnual, 2);
        $payeMonthly = round($payeAnnual / 12, 2);

        return [
            'gross'           => $grossAnnual,
            'cra'             => round($cra, 2),
            'taxable_income'  => round($taxableIncome, 2),
            'paye_annual'     => $payeAnnual,
            'paye_monthly'    => $payeMonthly,
            'effective_rate'  => $grossAnnual > 0
                                 ? round($payeAnnual / $grossAnnual * 100, 2)
                                 : 0,
            'band_breakdown'  => $breakdown,
        ];
    }

    // =========================================================================
    // PENSION / NHF / NSITF CALCULATIONS
    // =========================================================================

    /**
     * Calculate statutory payroll deductions for one employee per month.
     *
     * @param  float $basicMonthly      Basic salary (monthly)
     * @param  float $housingMonthly    Housing allowance (monthly)
     * @param  float $transportMonthly  Transport allowance (monthly)
     * @return array All deductions broken out
     */
    public function calculatePayrollLevies(
        float $basicMonthly,
        float $housingMonthly,
        float $transportMonthly
    ): array {
        $emoluments = $basicMonthly + $housingMonthly + $transportMonthly;
        $gross      = $basicMonthly + $housingMonthly + $transportMonthly; // simplified

        $pensionEmployer = round($emoluments * self::PENSION_EMPLOYER, 2);
        $pensionEmployee = round($emoluments * self::PENSION_EMPLOYEE, 2);
        $nhf             = round($basicMonthly * self::NHF_RATE, 2);
        $nsitf           = round($gross * self::NSITF_RATE, 2);

        return [
            'emoluments'       => $emoluments,
            'pension_employer' => $pensionEmployer,
            'pension_employee' => $pensionEmployee,
            'nhf'              => $nhf,
            'nsitf'            => $nsitf,
            'total_employer_cost' => $pensionEmployer + $nsitf,
            'total_employee_deductions' => $pensionEmployee + $nhf,
            'accounts' => [
                'pension_employer' => '2121',
                'pension_employee' => '2122',
                'nhf'              => '2123',
                'nsitf'            => '2124',
            ],
        ];
    }

    // =========================================================================
    // CIT CALCULATION
    // =========================================================================

    /**
     * Calculate Companies Income Tax and Development Levy.
     *
     * @param  float $annualTurnover    Gross annual turnover
     * @param  float $assessableProfit  Assessable profit (taxable income)
     * @return array { size, cit_rate, cit_amount, dev_levy_rate, dev_levy_amount,
     *                 minimum_tax, total_tax, effective_rate }
     */
    public function calculateCIT(float $annualTurnover, float $assessableProfit): array
    {
        if ($annualTurnover <= self::CIT_SMALL_THRESHOLD) {
            $size    = 'SMALL';
            $citRate = self::CIT_SMALL;
        } elseif ($annualTurnover <= self::CIT_MEDIUM_THRESHOLD) {
            $size    = 'MEDIUM';
            $citRate = self::CIT_MEDIUM;
        } else {
            $size    = 'LARGE';
            $citRate = self::CIT_LARGE;
        }

        $citAmount    = round($assessableProfit * $citRate, 2);
        $minTax       = round($annualTurnover * self::MIN_TAX, 2);
        $effectiveCIT = max($citAmount, $size !== 'SMALL' ? $minTax : 0);

        $devLevyAmount = $size !== 'SMALL'
            ? round($assessableProfit * self::DEV_LEVY, 2)
            : 0.00;

        $totalTax = $effectiveCIT + $devLevyAmount;

        return [
            'size'            => $size,
            'cit_rate'        => $citRate,
            'cit_amount'      => $citAmount,
            'minimum_tax'     => $minTax,
            'effective_cit'   => $effectiveCIT,
            'min_tax_applies' => $size !== 'SMALL' && $minTax > $citAmount,
            'dev_levy_rate'   => $size !== 'SMALL' ? self::DEV_LEVY : 0,
            'dev_levy_amount' => $devLevyAmount,
            'total_tax'       => $totalTax,
            'effective_rate'  => $assessableProfit > 0
                                 ? round($totalTax / $assessableProfit * 100, 2)
                                 : 0,
            'accounts' => [
                'cit_expense'       => '7000',
                'dev_levy_expense'  => '7001',
                'cit_payable'       => '2130',
                'dev_levy_payable'  => '2131',
            ],
            'note' => $size === 'SMALL'
                ? 'Small company: exempt from CIT, Development Levy, and CGT (NTA 2025 §56)'
                : ($size === 'LARGE' ? 'Note: CIT transitions to 25% from 2026 YOA per NTA 2025' : ''),
        ];
    }

    // =========================================================================
    // COMPLIANCE STATUS
    // =========================================================================

    /**
     * Get compliance status for a given period (YYYY-MM).
     * Checks last remittance dates against expected deadlines.
     *
     * @param  string $period  Format: 'YYYY-MM'
     * @param  int    $entity  Dolibarr entity ID
     * @return array  Per-obligation status: RED / AMBER / GREEN
     */
    public function getComplianceStatus(string $period, int $entity = 1): array
    {
        [$year, $month] = explode('-', $period);
        $today = date('Y-m-d');
        $statuses = [];

        $obligations = [
            ['id' => 'PAYE',    'deadline' => sprintf('%s-%s-10', $year, $month), 'account' => '2120'],
            ['id' => 'VAT',     'deadline' => sprintf('%s-%s-21', $year, $month), 'account' => '2100'],
            ['id' => 'WHT',     'deadline' => sprintf('%s-%s-21', $year, $month), 'account' => '2110'],
            ['id' => 'NSITF',   'deadline' => date('Y-m-t', mktime(0,0,0,(int)$month+1,1,$year)), 'account' => '2124'],
            ['id' => 'PENSION', 'deadline' => sprintf('%s-%s-07', $year, $month), 'account' => '2121'],
        ];

        foreach ($obligations as $ob) {
            $daysUntil = (strtotime($ob['deadline']) - strtotime($today)) / 86400;

            // Check if balance on account is zero (filed) — simplified heuristic
            $balance = $this->getAccountBalance($ob['account'], $period, $entity);

            if ($balance == 0) {
                $status = 'GREEN';
                $label  = 'Filed & remitted';
            } elseif ($daysUntil < 0) {
                $status = 'RED';
                $label  = 'OVERDUE — penalty accruing';
            } elseif ($daysUntil <= 5) {
                $status = 'AMBER';
                $label  = "Due in " . ceil($daysUntil) . " day(s) — action required";
            } else {
                $status = 'GREEN';
                $label  = "Due " . $ob['deadline'] . " (" . ceil($daysUntil) . " days)";
            }

            $statuses[$ob['id']] = [
                'obligation' => $ob['id'],
                'deadline'   => $ob['deadline'],
                'status'     => $status,
                'label'      => $label,
                'balance'    => $balance,
            ];
        }

        return $statuses;
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    /**
     * Get closing balance on a ledger account for a period.
     * Returns 0 if no entries found.
     */
    private function getAccountBalance(string $accountNumber, string $period, int $entity): float
    {
        [$year, $month] = explode('-', $period);
        $periodStart = $year . '-' . $month . '-01';
        $periodEnd   = date('Y-m-t', strtotime($periodStart));

        $sql = "SELECT SUM(debit) - SUM(credit) as balance
                FROM llx_accounting_bookkeeping
                WHERE entity = " . (int)$entity . "
                  AND numero_compte = '" . $this->db->escape($accountNumber) . "'
                  AND doc_date BETWEEN '" . $periodStart . "' AND '" . $periodEnd . "'";

        $res = $this->db->query($sql);
        if ($res) {
            $obj = $this->db->fetch_object($res);
            return (float)($obj->balance ?? 0);
        }
        return 0;
    }

    /**
     * Format amount as Nigerian Naira string.
     *
     * @param  float $amount
     * @return string  e.g. "₦1,250,000.00"
     */
    public static function formatNGN(float $amount): string
    {
        return '₦' . number_format($amount, 2);
    }

    /**
     * Get all accounts from the Nigerian COA.
     *
     * @param  int    $entity
     * @param  string $type  Optional filter: ASSET / LIABILITY / INCOME / EXPENSE / EQUITY
     * @return array
     */
    public function getChartOfAccounts(int $entity = 1, string $type = ''): array
    {
        $sql = "SELECT account_number, label, pcg_type, pcg_subtype, active
                FROM llx_accounting_account
                WHERE fk_pcg_version = 'NG-IFRS-SME'
                  AND entity = " . (int)$entity;

        if (!empty($type)) {
            $sql .= " AND pcg_type = '" . $this->db->escape($type) . "'";
        }

        // FIX BUG 2: correct column names for Dolibarr 15-19
        $sql .= " ORDER BY numero_compte ASC";

        $res      = $this->db->query($sql);
        $accounts = [];
        if ($res) {
            while ($obj = $this->db->fetch_object($res)) {
                $accounts[] = (array)$obj;
            }
        }
        return $accounts;
    }

    // =========================================================================
    // FX REVALUATION  (v2 — IAS 21)
    // =========================================================================

    /**
     * Revalue all open multi-currency invoices against current saved FX rates.
     * Returns unrealised gain/loss per invoice and aggregate totals.
     *
     * @param  int    $entity
     * @param  string $reval_date  YYYY-MM-DD
     * @return array {
     *   items: [{ ref, currency, fc_amount, original_rate, current_rate,
     *             ngn_original, ngn_current, fx_difference, type }],
     *   total_gain, total_loss, net_fx,
     *   journal_entry: { dr_account, cr_account, amount, description }
     * }
     */
    public function revalueFX(int $entity = 1, string $reval_date = ''): array
    {
        if (!$reval_date) $reval_date = date('Y-m-d');

        // Get latest rates per currency
        $rates = [];
        $sql_rates = "SELECT currency_code, rate_to_ngn
                      FROM llx_b3eqng_fx_rates
                      WHERE entity = " . (int)$entity . "
                        AND rate_date = (
                          SELECT MAX(r2.rate_date) FROM llx_b3eqng_fx_rates r2
                          WHERE r2.entity = " . (int)$entity . "
                            AND r2.currency_code = llx_b3eqng_fx_rates.currency_code
                            AND r2.rate_date <= '" . $this->db->escape($reval_date) . "'
                        )";
        $res_rates = $this->db->query($sql_rates);
        if ($res_rates) {
            while ($o = $this->db->fetch_object($res_rates)) {
                $rates[$o->currency_code] = (float)$o->rate_to_ngn;
            }
        }

        if (empty($rates)) {
            return [
                'items' => [], 'total_gain' => 0, 'total_loss' => 0, 'net_fx' => 0,
                'error' => 'No FX rates found for ' . $reval_date . '. Add rates via FX Revaluation page.',
            ];
        }

        // Open multi-currency invoices
        $sql_inv = "SELECT rowid, ref, multicurrency_code as currency,
                           multicurrency_total_ht as fc_amount,
                           multicurrency_tx as original_rate,
                           total_ht as ngn_at_invoice
                    FROM llx_facture
                    WHERE entity = " . (int)$entity . "
                      AND fk_statut = 1
                      AND multicurrency_code IS NOT NULL
                      AND multicurrency_code != ''
                      AND multicurrency_code != 'NGN'";
        $res_inv = $this->db->query($sql_inv);

        $items      = [];
        $total_gain = 0.0;
        $total_loss = 0.0;

        if ($res_inv) {
            while ($inv = $this->db->fetch_object($res_inv)) {
                $ccy           = $inv->currency;
                $current_rate  = $rates[$ccy] ?? null;
                if (!$current_rate) continue;

                $fc_amount     = (float)$inv->fc_amount;
                $orig_rate     = (float)$inv->original_rate;
                $ngn_original  = round($fc_amount * $orig_rate, 2);
                $ngn_current   = round($fc_amount * $current_rate, 2);
                $fx_diff       = round($ngn_current - $ngn_original, 2);

                if ($fx_diff > 0) $total_gain += $fx_diff;
                if ($fx_diff < 0) $total_loss += abs($fx_diff);

                $items[] = [
                    'rowid'         => (int)$inv->rowid,
                    'ref'           => $inv->ref,
                    'currency'      => $ccy,
                    'fc_amount'     => $fc_amount,
                    'original_rate' => $orig_rate,
                    'current_rate'  => $current_rate,
                    'ngn_original'  => $ngn_original,
                    'ngn_current'   => $ngn_current,
                    'fx_difference' => $fx_diff,
                    'type'          => $fx_diff >= 0 ? 'GAIN' : 'LOSS',
                ];
            }
        }

        $net_fx = round($total_gain - $total_loss, 2);

        // Build adjusting journal entry
        if ($net_fx >= 0) {
            $journal_entry = [
                'dr_account'  => '1500',  // Unrealised FX Gain Receivable
                'cr_account'  => '4106',  // Unrealised FX Gain (P&L)
                'amount'      => $net_fx,
                'description' => 'Unrealised FX Gain — revaluation ' . $reval_date . ' (IAS 21)',
                'note'        => 'Reverse at start of next period.',
            ];
        } else {
            $journal_entry = [
                'dr_account'  => '8004',  // Unrealised FX Loss
                'cr_account'  => '2300',  // Unrealised FX Loss Payable
                'amount'      => abs($net_fx),
                'description' => 'Unrealised FX Loss — revaluation ' . $reval_date . ' (IAS 21)',
                'note'        => 'Reverse at start of next period.',
            ];
        }

        return [
            'items'         => $items,
            'total_gain'    => $total_gain,
            'total_loss'    => $total_loss,
            'net_fx'        => $net_fx,
            'journal_entry' => $journal_entry,
            'reval_date'    => $reval_date,
            'rates_used'    => $rates,
        ];
    }

    // =========================================================================
    // DEPRECIATION BATCH RUN  (v2)
    // =========================================================================

    /**
     * Calculate monthly depreciation for all active assets.
     * Returns journal entries ready to post, one per asset.
     *
     * @param  int    $entity
     * @param  string $period  YYYY-MM
     * @return array  Array of { asset_ref, label, monthly_depr, account_dr, account_cr, journal }
     */
    public function calculateMonthlyDepreciation(int $entity = 1, string $period = ''): array
    {
        if (!$period) $period = date('Y-m');

        // Check custom table exists
        $table_check = $this->db->query("SHOW TABLES LIKE 'llx_b3eqng_assets'");
        if (!$table_check || $this->db->num_rows($table_check) === 0) {
            return ['error' => 'Asset table not yet created. Run SQL seed.'];
        }

        $sql = "SELECT * FROM llx_b3eqng_assets
                WHERE entity=" . (int)$entity . " AND status='ACTIVE'
                ORDER BY acquisition_date ASC";
        $res = $this->db->query($sql);
        if (!$res) return [];

        $entries = [];
        while ($asset = $this->db->fetch_object($res)) {
            $cost      = (float)$asset->acquisition_cost;
            $residual  = (float)$asset->residual_value;
            $life      = max(1, (int)$asset->useful_life_years);
            $depreciable = max(0, $cost - $residual);
            $nbv       = (float)$asset->net_book_value;

            // Skip fully depreciated assets
            if ($nbv <= $residual) continue;

            if ($asset->depreciation_method === 'DECLINING_BALANCE') {
                $annual_rate = 2 / $life;
                $monthly_depr = round(($nbv * $annual_rate) / 12, 2);
            } else {
                // Straight-line
                $monthly_depr = round(($depreciable / $life) / 12, 2);
            }

            // Cap at remaining depreciable amount
            $remaining = $nbv - $residual;
            $monthly_depr = min($monthly_depr, $remaining);
            if ($monthly_depr <= 0) continue;

            $entries[] = [
                'asset_rowid'    => (int)$asset->rowid,
                'asset_ref'      => $asset->ref,
                'label'          => $asset->label,
                'period'         => $period,
                'monthly_depr'   => $monthly_depr,
                'nbv_before'     => $nbv,
                'nbv_after'      => round($nbv - $monthly_depr, 2),
                'account_dr'     => $asset->account_expense ?? '6030',
                'account_cr'     => $asset->account_depr   ?? '1301',
                'journal_code'   => 'JV-FA',
                'description'    => 'Depreciation ' . $period . ' — ' . $asset->label . ' (' . $asset->ref . ')',
            ];
        }

        return $entries;
    }

    // =========================================================================
    // COMPATIBILITY HELPER  (v2 — BUG 8 fix)
    // =========================================================================

    /**
     * Get Dolibarr global constant, compatible with Dolibarr 15+.
     * getDolGlobalString() was introduced in Dolibarr 17.
     */
    public static function getConf(string $key, string $default = ''): string
    {
        global $conf;
        if (function_exists('getDolGlobalString')) {
            return getDolGlobalString($key, $default);
        }
        return isset($conf->global->$key) ? (string)$conf->global->$key : $default;
    }
}
