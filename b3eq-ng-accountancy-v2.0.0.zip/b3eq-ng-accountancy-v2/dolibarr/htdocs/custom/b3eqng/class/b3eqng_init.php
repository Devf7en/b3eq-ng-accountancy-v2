<?php
/* ============================================================================
 * b3Ɛq Nigerian Accountancy v2.0.0 — Page Bootstrap Helper
 * tagged: b3Ɛq Nigerian Accountancy
 * File:   htdocs/custom/b3eqng/class/b3eqng_init.php
 *
 * FIXES:
 *   BUG 4 — Fragile relative include paths on shared hosting
 *   BUG 5 — Rights check crashes before module activates
 *   BUG 7 — CSS injection via correct method
 *   BUG 8 — getDolGlobalString() compatibility
 *
 * Include at the TOP of every page/*.php and admin/*.php:
 *   require_once dirname(__DIR__) . '/class/b3eqng_init.php';
 * ============================================================================
 */

// ── Step 1: Bootstrap Dolibarr main.inc.php ───────────────────────────────────
// Walk up directory tree until main.inc.php is found.
// Works on any hosting layout, any nesting depth.
if (!defined('DOL_VERSION')) {
    $dir = __DIR__;
    $found = false;
    for ($i = 0; $i < 10; $i++) {
        $dir = dirname($dir);
        if (file_exists($dir . '/main.inc.php')) {
            require_once $dir . '/main.inc.php';
            $found = true;
            break;
        }
        if (file_exists($dir . '/htdocs/main.inc.php')) {
            require_once $dir . '/htdocs/main.inc.php';
            $found = true;
            break;
        }
    }
    if (!$found) {
        http_response_code(500);
        die('Cannot locate Dolibarr main.inc.php — check module installation path.');
    }
}

// ── Step 2: Load language file ────────────────────────────────────────────────
$langs->loadLangs(['b3eqng@b3eqng', 'bills', 'compta']);

// ── Step 3: Rights check (BUG 5 fix — isset guard) ───────────────────────────
if (!isset($user->rights->b3eqng) || empty($user->rights->b3eqng->read)) {
    // Fallback: admins always get access even if rights haven't propagated yet
    if (empty($user->admin)) {
        accessforbidden();
    }
}

// ── Step 4: Inject CSS (BUG 7 fix) ───────────────────────────────────────────
// Stored in a global so llxHeader can print it in <head>
$arrayofcss = [DOL_URL_ROOT . '/custom/b3eqng/css/b3eqng.css'];

// ── Step 5: getDolGlobalString compatibility (BUG 8 fix) ─────────────────────
if (!function_exists('b3eq_conf')) {
    /**
     * Compatibility wrapper for getDolGlobalString (Dolibarr 17+)
     * Falls back to $conf->global->KEY on older versions.
     */
    function b3eq_conf(string $key, string $default = ''): string
    {
        global $conf;
        if (function_exists('getDolGlobalString')) {
            return getDolGlobalString($key, $default);
        }
        return isset($conf->global->$key) ? (string)$conf->global->$key : $default;
    }
}

// ── Step 6: Require core business logic ──────────────────────────────────────
require_once DOL_DOCUMENT_ROOT . '/custom/b3eqng/class/b3eqng.class.php';
require_once DOL_DOCUMENT_ROOT . '/custom/b3eqng/class/audit_logger.class.php';

// ── Step 7: Helper to inject CSS link after llxHeader() ──────────────────────
if (!function_exists('b3eq_inject_css')) {
    function b3eq_inject_css(): void
    {
        echo '<link rel="stylesheet" href="' . DOL_URL_ROOT . '/custom/b3eqng/css/b3eqng.css?v=2.0.0">' . "\n";
    }
}
